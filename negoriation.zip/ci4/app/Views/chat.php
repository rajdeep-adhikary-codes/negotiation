<!DOCTYPE html>
<html>
<head>
    <title>Real-time Chat Application</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.0.1/socket.io.min.js"></script>
</head>
<body>
    <h1>Real-time Chat Application</h1>
    <div id="chat-box">
    </div>
    <form id="chat-form">
        <input type="text" name="message" placeholder="Type your message...">
        <button type="submit">Send</button>
    </form>
    <script>
        const socket = io.connect('http://localhost:8080'); // Connect to the Socket.io server
        
        $('#chat-form').submit(function(e) {
            e.preventDefault(); // Prevent the form from submitting
            
            // Get the message text
            const message = $('input[name="message"]').val();
            
            // Send the message to the server
            socket.emit('chat-message', message);
            
            // Clear the input field
            $('input[name="message"]').val('');
        });
        
        // Receive the chat message from the server and append it to the chat box
        socket.on('chat-message', function(message) {
            $('#chat-box').append($('<p>').text(message));
        });
    </script>
</body>
</html>
