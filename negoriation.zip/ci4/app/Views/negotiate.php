<!DOCTYPE html>
<html>
<head>
    <title>Negotiate</title>
    <!-- //bootstrap 4 css file -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <!-- //bootstrap 4 js file -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="<?= base_url('/public/css/negotiate.css') ?>">
</head>
<body>
    <!-- <h1>Real-time Chat Application</h1> -->
    
    <?php $amnt = 100; ?>
    <p class="negotiate-msg"></p>
    <button class="negotiate-btn">Negotiate</button>



    <!-- negotiate modal -->


    <!-- The Modal -->
    <div id="myModal" class="n-modal">

    <!-- Modal content -->
    <div class="n-modal-content">
    <div class="n-modal-header">
        <span class="n-close">&times;</span>
        <h2 class="negotiation-header">Exceeds budget? You can negotiate the amount</h2>
        <small>Submit your price below</small>
    </div>
    <div class="n-modal-body">
        <form class="userNegotiationForm">
            <input type="hidden" name="room_id" value="DUMMY_ROOM_ID">
            <input type="hidden" name="user_id" value="DUMMY_USER_ID">
            <input type="hidden" name="hours" value="DUMMY_HOUR">
            <!-- <input type="text" class="negotiation-input" name="original_amnt" id="original_amnt" value="<?= $amnt ?>" readonly>
            <input type="text" class="negotiation-input" name="negotiated_amnt" id="negotiated_amnt" value="" placeholder="Enter Your Amount"> -->
            <div class="d-flex">
                <div class="input-group mb-2 w-50">
                    <div class="input-group-prepend">
                    <div class="input-group-text" id="original_amnt_ig">₹</div>
                    </div>
                    <input type="text" class="negotiation-input" name="original_amnt" id="original_amnt" value="<?= $amnt ?>" readonly>
                </div>

                <div class="input-group mb-2 w-50">
                    <div class="input-group-prepend">
                    <div class="input-group-text" id="negotiated_amnt_ig">₹</div>
                    </div>
                    <input type="text" class="negotiation-input" name="negotiated_amnt" id="negotiated_amnt" value="" placeholder="Enter Your Amount">
                </div>
            </div>
        </form>
        <p class="text-danger" id="errorSpan">Some other text...</p>
    </div>
    <div class="n-modal-footer">
        <h3><button class="negotiateSubmitBtn">Submit Your Value</button></h3>
    </div>
    </div>

    </div>
    <script src="<?= base_url('/public/js/negotiate.js') ?>"></script>
</body>
</html>
