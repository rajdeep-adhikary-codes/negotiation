<!DOCTYPE html>
<html>
<head>
    <title>Negotiate</title>
    <!-- //bootstrap 4 css file -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <!-- //bootstrap 4 js file -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="<?= base_url('/public/admin/styles.css') ?>">
</head>
<body>
   

    <div class="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Incoming Negotiation Request</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Property : <span></span>
                    Room : <span></span>
                    Floor : <span></span>
                    Original Amount : <span></span>
                    Negotiated Amount : <span></span>
                    For Hours : <span></span>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary">Accept</button>
                    <button type="button" class="btn btn-primary">Decline</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>


    <script src="<?= base_url('/public/admin/script.js') ?>"></script>
</body>
</html>
