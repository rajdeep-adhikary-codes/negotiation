<?php



namespace App\Models;



use CodeIgniter\Model;



class CommonModel extends Model

{

    protected $table = 'negotiation';

    public function __construct()

    {

        $this->db = \Config\Database::connect();

    }

    public function getStates()

    {

        return $this->db->query("SELECT * FROM `states` WHERE STATUS = 'A';")->getResultArray();

    }

    public function getCategories()

    {

        return $this->db->query("SELECT * FROM `categories_master` WHERE STATUS = 'A';")->getResultArray();

    }

    

    function inserIntoTable($table,$dataarray)

    {

        $this->db->table($table)->insert($dataarray);

        return $this->db->insertid();

    }



    public function getAllFromTable($table, $condition)

    {

        return $this->db->query("SELECT * FROM `$table` $condition")->getResultArray();

    }



    public function getPricesMinValue($property_id)

    {

        return $this->db->query("SELECT rent_three_hour AS rent_three_hour, rent_six_hour AS rent_six_hour, rent_nine_hour AS rent_nine_hour, rent_daily AS rent_daily FROM `rooms` WHERE property_id = '$property_id' ORDER BY rent_three_hour DESC limit 1;")->getRow();

    }

    public function verifyOtp($emailorphone, $otp)
    {
        return $this->db->query("SELECT COUNT(*) as matched FROM `login_otp` WHERE email_or_phone = '$emailorphone' and otp = '$otp' ORDER BY datetime DESC")->getRow();
    }
    public function updateUserName($id, $name)
    {
        $this->db->table('users')->where('hash_id', $id)->update(['full_name' => $name]);
        return $this->db->affectedRows();
    }

    public function getHotelDetailsById($id = 0)
    {
        if($id != 0){
            return $this->db->query("SELECT * FROM `property_mstr` WHERE property_id = '$id' and property_status = 'A';")->getRow();
        }
        else{
            return null;
        }
    }

    public function getRoomsByPropertyId($id = 0)
    {
        if($id != 0){
            return $this->db->query("SELECT room_type.room_type, MIN(rooms.rent_three_hour) as rent_three_hour, rooms.rent_six_hour, rooms.rent_nine_hour, rooms.rent_daily, rooms.room_id FROM `rooms` INNER JOIN room_type ON rooms.room_type = room_type.room_type_id WHERE property_id = '$id' and rooms.status = 'A' GROUP BY room_type.room_type;")->getResult();
        }
        else{
            return [];
        }
    }

    public function updateOrderDataByOrderId($orderId, $data)
    {
        $this->db->table('bookings')->where('razorpay_order_id', $orderId)->update($data);
        return $this->db->affectedRows();
    }

    public function getAvailableRoomsByPropertyIdAndDate($property_id, $from, $to)
    {
        return $this->db->query("SELECT r.room_id
        FROM rooms r
        LEFT JOIN bookings b ON r.room_id = b.room_id
            AND (
                (b.date_from <= '$to' AND b.date_to >= '$from')
                OR (b.date_from <= '$from' AND b.date_to >= '$to')
                OR (b.date_from >= '$from' AND b.date_to <= '$to')
            )
        WHERE r.property_id = '$property_id'
            AND (b.booking_id IS NULL OR b.transaction_status <> 'COMPLETE')")->getResult();
    }
}