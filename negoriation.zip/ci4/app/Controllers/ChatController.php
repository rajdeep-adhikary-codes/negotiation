<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class ChatController extends Controller
{
    public function index()
    {
        return view('chat');
    }
}
