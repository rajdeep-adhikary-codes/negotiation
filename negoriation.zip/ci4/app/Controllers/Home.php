<?php

namespace App\Controllers;
use \App\Models\CommonModel;

class Home extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }

    public function hello()
    {
        echo 'Hello';
    }

    function negotiateView() {
        return view('negotiate');
    }

    function submitNegotiation() {

        $cModel = new CommonModel();

        $user_id = $_POST['user_id'];
        $room_id = $_POST['room_id'];
        $hours = $_POST['hours'];
        $original_amnt = $_POST['original_amnt'];
        $negotiated_amnt = $_POST['negotiated_amnt'];

        $data = [
            "negotiation_id" => rand(1000, 9999),
            "user_id" => $user_id,
            "room_id" => $room_id,
            "hours" => $hours,
            "original_amnt" => $original_amnt,
            "negotiated_amnt" => $negotiated_amnt,
        ];

        $inserted = $cModel->inserIntoTable('negotiation', $data);

        if($inserted > 0){
            $response = [
                'success' => true,
                'message' => 'Negotiation Request Sent. Please wait for the hotel owner to review your bid.'
            ];
        }
        else{
            $response = [
                'success' => false,
                'message' => 'Unable to send Negotiation Request. Please try again after some time.'
            ];
        }
        echo json_encode($response);
    }

    function checkNegotiation() {

        $cModel = new CommonModel();

        $user_id = $_POST['user_id'];
        $room_id = $_POST['room_id'];
        $original_amnt = $_POST['original_amnt'];
        $negotiated_amnt = $_POST['negotiated_amnt'];

        $negotiations = $cModel->getAllFromTable('negotiation', "  WHERE user_id = '$user_id' AND room_id = '$room_id' AND negotiation_status = 'PENDING' AND created_on > DATE_SUB(NOW(),INTERVAL 1 DAY)");

        // print_r($negotiations); die;

        if(count($negotiations) > 0){
            $response = [
                'success' => false,
                'message' => 'Your Request For this room is still Pending. Please have patience'
            ];
        }
        else{
            $response = [
                'success' => true,
                'message' => ''
            ];
        }

        echo json_encode($response);
    }

    function adminNegotiation() {
        return view('admin-negotiation');
    }
}
