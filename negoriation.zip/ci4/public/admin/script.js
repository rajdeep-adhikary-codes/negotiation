
function checkNegotiations(){
    let data = {
        property_id : 'ABC',
        room_id : '1',
        floor : '2',
        original_amnt : 200,
        negotiated_amnt : 150,
        hours : 4,
        negotiation_id : '1234'
    }
    showNegotiation(data);
}


function showNegotiation(data){
    const modal = `<div class="modal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Incoming Negotiation Request</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Property : <span>${data.property_id}</span><br>
                        Room : <span>${data.room_id}</span><br>
                        Floor : <span>${data.floor}</span><br>
                        Original Amount : <span>${data.original_amnt}</span><br>
                        Negotiated Amount : <span>${data.negotiated_amnt}</span><br>
                        For Hours : <span>${data.hours}</span><br>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="replyNegotiation('${data.negotiation_id}', 'ACCEPTED')">Accept</button>
                        <button type="button" class="btn btn-primary" onclick="replyNegotiation('${data.negotiation_id}', 'DECLINED'')">Decline</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>`;

        $('body').append(modal);

        $('.modal').show();
}

$(document).ready(function(){
    checkNegotiations();
})