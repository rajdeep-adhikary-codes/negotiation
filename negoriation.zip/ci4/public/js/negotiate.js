const modal = document.getElementById("myModal");


$(document).on('click', '.negotiate-btn', function(){
    modal.style.display = "block";
})


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }

$('.n-close').click(function(){
    modal.style.display = "none";
})

$(document).ready(function(){

    checkNegotiationStatus();

    $('.negotiateSubmitBtn').click(function(e){
        let data = $('.userNegotiationForm').serialize();

        $.ajax({
            url : 'submitNegotiation',
            method : 'post',
            data : data,
            error : function(){

            },
            success : function(data){
                data = JSON.parse(data);
                if(data.success){
                    disableNegotiation(data.message);
                    alert(data.message);
                    modal.style.display = "none";
                }
                else{
                    alert(data.message);
                }
            }
        })
        
    })
})

const disableNegotiation = (msg) => {
    const negotiateButton = $(".negotiate-btn");
    negotiateButton.attr("disabled", true);
    $('.negotiate-msg').html(msg);
}

function checkNegotiationStatus(){
    let data = $('.userNegotiationForm').serialize();

    $.ajax({
        url : 'checkNegotiation',
        method : 'post',
        data : data,
        error : function(){

        },
        success : function(data){
            data = JSON.parse(data);
            if(data.success === false){
                disableNegotiation(data.message);
            }
            else{
                
            }
        }
    })
}